import pygame
import random
from player import Player
from level import *
from Highscore import *

pygame.init()
game_width = 650
game_height = 700
screen = pygame.display.set_mode((game_width, game_height))
clock = pygame.time.Clock()
running = True

#Create Player object
player = Player()

#Create list of platforms
platforms = []

#Create list of ladders
ladders= []

snakes = []
snake_spawn_timer_max = 100
snake_spawn_timer = snake_spawn_timer_max
current_level = 1

#number of sneks
max_snakes = 8 + current_level * 2
print(max_snakes)
chance_to_spawn = 40

font = pygame.font.SysFont("Default", 40)
next_level_text = font.render("press enter for next level", True, (0, 0, 0))
restart_text = font.render("press enter to restart", True, (0, 0, 0))
gameover_text = font.render("game over", True, (0, 0, 0))

def end_screen():
    screen.fill((0, 0, 0))
    gameover_text = font.render("game over", True, (255, 255, 255))
    screen.blit(gameover_text, (250,200))
    level_text = font.render('level: '+str(current_level), True, (255, 255, 255))
    screen.blit(level_text, (250,233 ))
    score_text = font.render('score: '+str(player.score), True, (255, 255, 255))
    screen.blit(score_text, (250, 260))
    end_player_score = player.score
    
def spawn_snakes():
    global snakes
    for i in range(1, 6):
        if random.randint(0, 100) <= chance_to_spawn:
            if len(snakes) < max_snakes:
                if i % 2 == 0:
                    snakes.append(Snake(0, platforms[i].rect.y + 1, 1, current_level+1))
                else:
                    snakes.append(Snake(600, platforms[i].rect.y + 1, -1, current_level+1))
            


def start():
    global ladders
    ladders = []

    global snakes
    snakes = []
    
    platforms.append(Platform(0, 670, 13))
    for i in range(3):
        platforms.append(Platform(100, 570 - (200 * i), 11))
        platforms.append(Platform(0, 470 - (200 * i), 11))

    #spawn ladders in different locations
    for i in range(6):
        l = Ladder(random.randint(100,500), platforms[i].rect.y, 5)
        #if ladder is touching another ladder, move it
        while l.rect.collidelist(ladders) > -1:
            l = Ladder(random.randint(100, 500), platforms[i].rect.y, 5)
        ladders.append(l)
    player.reset(0, 670)
    
start()
# Main Loop
while running:

    max_snakes = 8 + current_level * 2

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            running = False
        if event.type == pygame.KEYDOWN and event.key == pygame.K_r:
            start()

    for p in platforms:
        p.update(screen)
        
    for l in ladders:
        l.update(screen)

    snake_spawn_timer -= 1
    if snake_spawn_timer <= 0:
        spawn_snakes()
        snake_spawn_timer = snake_spawn_timer_max

    for s in snakes:
        if s.rect.y > game_height:
            snakes.remove(s)
        else:
            s.update(screen, platforms)
    
    keys = pygame.key.get_pressed()
    player.update(screen, keys, platforms, ladders, snakes)
    scores = True

    if player.score >= 100:
        scores = False
        screen.blit(score_text, (510, 50))
            
    lives_text = font.render('lives: '+str(player.lives), True, (0, 0, 0))
    screen.blit(lives_text, (0,0))
    level_text = font.render('level: '+str(current_level), True, (0, 0, 0))
    screen.blit(level_text, (525,0))
    score_text = font.render('score: '+str(player.score), True, (0, 0, 0))
    if scores == True:
        screen.blit(score_text, (525, 50))
    snakes_text = font.render('snakes: '+str(max_snakes), True, (0, 0, 0))
    screen.blit(snakes_text, (130, 0))
    #leveldisplay_text = font.render('level: '+str(current_level), True, (0, 0, 0))
        

    if player.grounded and player.rect.colliderect(platforms[len(platforms) - 1]):
        player.win()

    if not player.alive:
        if player.lives > 0:
            screen.blit(restart_text, (0,50))
            if keys[pygame.K_RETURN]:
                start()
        else:
            end_screen()

    if player.has_won:
        screen.blit(next_level_text, (0,50))
        if keys[pygame.K_RETURN]:
            current_level += 1
            player.lives += 1
            start()
    if keys[pygame.K_TAB]:
        end_screen()
                                    
    pygame.display.flip()
    clock.tick(50)
    screen.fill((80, 155, 250))





