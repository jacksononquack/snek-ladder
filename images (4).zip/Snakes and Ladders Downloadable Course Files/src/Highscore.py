from main import *

running = True
highscore = 0
while running:
    if end_player_score > highscore:
        highscore = end_player_score
    
    
